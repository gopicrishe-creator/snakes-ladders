'use strict';

/**
 * Loads each HTML page's scripts the way a browser does — into one shared
 * global scope, in order — and checks the buttons actually get handlers.
 *
 * This exists because `node --check` on individual files passes even when two
 * of them declare the same top-level name, which is a SyntaxError in the
 * browser and silently kills every listener on the page.
 */

const fs = require('fs');
const path = require('path');
const vm = require('vm');
const assert = require('assert');

const PUB = path.join(__dirname, '..', 'public');
const board = require('../src/board');

let pass = 0;
const ok = (m) => { pass += 1; console.log(`  \u2713 ${m}`); };

/** Minimal DOM: enough for the scripts to run and register listeners. */
function makeDom(html) {
  const ids = [...html.matchAll(/id="([^"]+)"/g)].map((m) => m[1]);
  const nodes = new Map();
  const listeners = [];

  const makeNode = (id) => ({
    id,
    style: {},
    dataset: {},
    classList: { add() {}, remove() {}, toggle() {}, contains: () => false },
    className: '',
    hidden: false,
    innerHTML: '',
    textContent: '',
    value: '',
    disabled: false,
    lastChild: { textContent: '' },
    children: [],
    appendChild(c) { this.children.push(c); return c; },
    append(...c) { this.children.push(...c); },
    remove() {},
    setAttribute() {},
    getAttribute() { return null; },
    querySelector() { return makeNode('q'); },
    querySelectorAll() { return []; },
    addEventListener(ev, fn) { listeners.push({ id, ev, fn }); },
    closest() { return null; },
    focus() {},
  });

  ids.forEach((id) => nodes.set(id, makeNode(id)));

  const document = {
    getElementById: (id) => nodes.get(id) || null,
    createElement: (tag) => makeNode(`<${tag}>`),
    createElementNS: (ns, tag) => makeNode(`<${tag}>`),
    querySelector: () => null,
    body: makeNode('body'),
    addEventListener() {},
  };
  return { document, listeners, nodes };
}

function loadPage(htmlFile, scripts) {
  const html = fs.readFileSync(path.join(PUB, htmlFile), 'utf8');
  const { document, listeners, nodes } = makeDom(html);

  const emitted = [];
  const socket = {
    on() {}, off() {}, close() {},
    emit(ev, payload) { emitted.push({ ev, payload }); },
  };

  const sandbox = {
    document,
    console,
    setTimeout,
    clearTimeout,
    setInterval: () => 0,
    clearInterval() {},
    io: () => socket,
    localStorage: {
      store: {},
      getItem(k) { return this.store[k] || null; },
      setItem(k, v) { this.store[k] = v; },
      removeItem(k) { delete this.store[k]; },
    },
    location: { search: '', host: 'example.test' },
    matchMedia: () => ({ matches: false }),
    URLSearchParams,
    Math,
    Date,
    JSON,
    Set,
    Map,
    Promise,
  };
  sandbox.window = sandbox;
  sandbox.window.SNL_CONFIG = {
    snakes: board.SNAKES,
    ladders: board.LADDERS,
    finalSquare: board.FINAL_SQUARE,
    maxPlayers: board.MAX_PLAYERS,
    colors: board.PLAYER_COLORS,
  };

  const ctx = vm.createContext(sandbox);
  scripts.forEach((s) => {
    const code = fs.readFileSync(path.join(PUB, s), 'utf8');
    vm.runInContext(code, ctx, { filename: s });
  });

  return { sandbox, listeners, nodes, emitted, socket };
}

console.log('\nClient pages');

{
  const { sandbox, listeners } = loadPage('admin.html', ['common.js', 'board.js', 'admin.js']);
  ok('admin page scripts load together without a scope collision');

  assert.ok(sandbox.window.SNL, 'window.SNL survived the IIFE wrap');
  assert.ok(sandbox.window.SNLBoard, 'window.SNLBoard survived the IIFE wrap');
  ok('shared helpers are still exported to window');

  const wired = new Set(listeners.filter((l) => l.ev === 'click').map((l) => l.id));
  ['btn-create', 'btn-attach', 'c-start', 'c-pause', 'c-resume', 'c-skip', 'c-force', 'c-reset', 'c-end']
    .forEach((id) => assert.ok(wired.has(id), `${id} has no click handler`));
  ok(`every host control is wired (${wired.size} buttons)`);
}

{
  const { listeners, emitted, nodes } = loadPage('admin.html', ['common.js', 'board.js', 'admin.js']);
  const create = listeners.find((l) => l.id === 'btn-create' && l.ev === 'click');
  create.fn({ preventDefault() {} });
  assert.strictEqual(emitted.length, 1);
  assert.strictEqual(emitted[0].ev, 'admin:create');
  assert.ok(emitted[0].payload.sessionId, 'a session id is sent');
  ok('clicking "Create a new room" emits admin:create');

  const start = listeners.find((l) => l.id === 'c-start');
  start.fn({});
  assert.strictEqual(emitted[1].ev, 'admin:start');
  ok('clicking "Start game" emits admin:start');

  void nodes;
}

{
  const { sandbox, listeners } = loadPage('index.html', ['common.js', 'board.js', 'player.js']);
  ok('player page scripts load together without a scope collision');

  assert.ok(sandbox.window.SNL && sandbox.window.SNLBoard);
  const wired = new Set(listeners.filter((l) => l.ev === 'click').map((l) => l.id));
  ['btn-join', 'btn-roll'].forEach((id) => assert.ok(wired.has(id), `${id} has no click handler`));
  ok('join and roll buttons are wired');
}

{
  const { listeners, emitted, nodes } = loadPage('index.html', ['common.js', 'board.js', 'player.js']);
  nodes.get('in-code').value = 'SL-1234';
  nodes.get('in-name').value = 'Ana';
  listeners.find((l) => l.id === 'btn-join' && l.ev === 'click').fn({});
  assert.strictEqual(emitted[0].ev, 'player:join');
  assert.strictEqual(emitted[0].payload.code, 'SL-1234');
  assert.strictEqual(emitted[0].payload.name, 'Ana');
  ok('clicking "Join the game" emits player:join with the typed code and name');

  listeners.find((l) => l.id === 'btn-roll' && l.ev === 'click').fn({});
  assert.strictEqual(emitted[1].ev, 'player:roll');
  ok('clicking "Roll dice" emits player:roll');
}

{
  // Every script the HTML references must exist and parse.
  ['index.html', 'admin.html'].forEach((page) => {
    const html = fs.readFileSync(path.join(PUB, page), 'utf8');
    const srcs = [...html.matchAll(/<script src="\/([^"]+)"/g)].map((m) => m[1]);
    srcs.filter((s) => !s.startsWith('socket.io') && s !== 'config.js').forEach((s) => {
      assert.ok(fs.existsSync(path.join(PUB, s)), `${page} references missing ${s}`);
    });
  });
  ok('every script tag points at a file that exists');
}

console.log(`\n${pass} checks passed.\n`);
